﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;
private readonly HttpClient http = new HttpClient();

namespace ProyectoCalculadora
{
    public partial class Form1 : Form
    {
        private double valor1 = 0, valor2 = 0;
        private string operacion = "";
        private bool esOperacionUnaria = false;
        //la base de datos
        private string conexion = "Server=PC-RODOLFO;Database=CalculadoraDB;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;";

        public Form1()
        {
            InitializeComponent();

  
            for (int i = 0; i <= 9; i++)
            {
                var control = Controls["button" + i];
                if (control is not null)
                    control.Click += numeroClick!;
            }

     
            string[] botonesOperaciones = { "Suma", "Resta", "Multiplicacion", "Division", "Raiz", "Porcentaje", "Elevado", "Borrar", "C", "CE", "Igual", "Punto" };
            foreach (string boton in botonesOperaciones)
            {
                var control = Controls["button" + boton];
                if (control is not null)
                    control.Click += botonClick!;
            }
        }

        //agrega numero o operacion al textbox
        private void numeroClick(object? sender, EventArgs e)
        {
            if (sender is Button boton)
                txtOperacion.Text += boton.Text;
        }

        private void botonClick(object? sender, EventArgs e)
        {
            if (sender is Button boton)
            {
                switch (boton.Name)
                {
                    case "buttonIgual":
                        calcularResultado();
                        break;
                    case "buttonBorrar":
                        if (txtOperacion.Text.Length > 0)
                            txtOperacion.Text = txtOperacion.Text.Remove(txtOperacion.Text.Length - 1);
                        break;
                    case "buttonC":
                    case "buttonCE":
                        txtOperacion.Text = "";
                        txtResultado.Text = "";
                        break;
                    case "buttonRaiz":
                    case "buttonPorcentaje":
                    case "buttonElevado":
                        agregarOperacionUnaria(boton);
                        break;
                    case "buttonResta":
                        manejarRestaONegativo();
                        break;
                    default:
                        operacionClick(boton);
                        break;
                }
            }
        }

        private void operacionClick(Button boton)
        {
            if (!string.IsNullOrEmpty(txtOperacion.Text))
            {
                valor1 = double.Parse(txtOperacion.Text);
                operacion = boton.Name switch
                {
                    "buttonSuma" => "+",
                    "buttonResta" => "-",
                    "buttonMultiplicacion" => "*",
                    "buttonDivision" => "/",
                    _ => operacion
                };
                txtOperacion.Text += " " + operacion + " ";
                txtResultado.Text = "";
            }
        }

        private async void calcularResultado()
        {
            try
            {
                string[] partes = txtOperacion.Text.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                if (partes.Length != 3)
                {
                    MessageBox.Show("Formato inválido de operación.");
                    return;
                }

                double v1 = double.Parse(partes[0]);
                string op = partes[1];
                double v2 = double.Parse(partes[2]);

                string endpoint = op switch
                {
                    "+" => "sumar",
                    "-" => "restar",
                    "*" => "multiplicar",
                    "/" => "dividir",
                    _ => ""
                };

                if (string.IsNullOrEmpty(endpoint))
                {
                    MessageBox.Show("Operación no válida.");
                    return;
                }

                // URL---------------------------------------------------------------------------
                string url = $"https://localhost:7059/api/Operaciones/{endpoint}?v1={v1}&v2={v2}";

                HttpResponseMessage response = await http.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Error de la API: " + response.ReasonPhrase);
                    return;
                }

                var data = await response.Content.ReadFromJsonAsync<dynamic>();

                double resultado = (double)data.resultado;

                txtResultado.Text = resultado.ToString();

                GuardarOperacion(v1, v2, op, resultado);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void agregarOperacionUnaria(Button boton)
        {
            if (double.TryParse(txtOperacion.Text, out valor1))
            {
                string operacionUnaria = boton.Name switch
                {
                    "buttonRaiz" => "raíz",
                    "buttonPorcentaje" => "porcentaje",
                    "buttonElevado" => "elevado",
                    _ => ""
                };

                txtOperacion.Text = $"{operacionUnaria}({txtOperacion.Text})";
                operacion = operacionUnaria;
                esOperacionUnaria = true;
            }
        }

        private void operarUnario()
        {
            try
            {
                if (double.TryParse(txtOperacion.Text.Trim(new[] { 'r', 'a', 'í', 'z', '(', ')', ' ', 'p', 'o', 'c', 'e', 'n', 't', 'a', 'j', 'e', 'e', 'l', 'v', 'a', 'd', 'o' }), out valor1))
                {
                    double resultado = operacion switch
                    {
                        "raíz" => Math.Sqrt(valor1),
                        "porcentaje" => valor1 / 100,
                        "elevado" => Math.Pow(valor1, 2),
                        _ => 0
                    };

                    txtResultado.Text = resultado.ToString();
                    GuardarOperacion(valor1, 0, operacion, resultado);
                    esOperacionUnaria = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en operación unaria: " + ex.Message);
            }
        }

        private void manejarRestaONegativo()
        {
            if (string.IsNullOrEmpty(txtOperacion.Text) || (txtOperacion.Text.Length == 1 && txtOperacion.Text == "-"))
            {
                txtOperacion.Text = "-";
            }
            else if (!txtOperacion.Text.EndsWith(" - ") && !txtOperacion.Text.Contains(" "))
            {
                txtOperacion.Text += " - ";
            }
        }
        //Base de datos(SQL)
        private void GuardarOperacion(double valor1, double valor2, string operacion, double resultado)
        {
            try
            {
                using SqlConnection conn = new SqlConnection(conexion);
                conn.Open();

                string query = "INSERT INTO Operaciones (Valor1, Operacion, Valor2, Resultado) VALUES (@v1, @op, @v2, @res)";
                using SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.Add("@v1", SqlDbType.Float).Value = valor1;
                cmd.Parameters.Add("@op", SqlDbType.VarChar, 20).Value = operacion;
                cmd.Parameters.Add("@v2", SqlDbType.Float).Value = valor2;
                cmd.Parameters.Add("@res", SqlDbType.Float).Value = resultado;

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar en la base de datos: " + ex.Message);
            }
        }

    }
}


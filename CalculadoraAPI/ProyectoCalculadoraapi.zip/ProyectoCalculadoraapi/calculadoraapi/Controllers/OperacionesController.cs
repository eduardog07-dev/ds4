﻿using Microsoft.AspNetCore.Mvc;

namespace calculadoraapi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OperacionesController : ControllerBase
    {
        [HttpGet("sumar")]
        public IActionResult Sumar(double v1, double v2)
        {
            return Ok(new
            {
                Valor1 = v1,
                Valor2 = v2,
                Operacion = "suma",
                Resultado = v1 + v2
            });
        }

        [HttpGet("restar")]
        public IActionResult Restar(double v1, double v2)
        {
            return Ok(new
            {
                Valor1 = v1,
                Valor2 = v2,
                Operacion = "resta",
                Resultado = v1 - v2
            });
        }

        [HttpGet("multiplicar")]
        public IActionResult Multiplicar(double v1, double v2)
        {
            return Ok(new
            {
                Valor1 = v1,
                Valor2 = v2,
                Operacion = "multiplicación",
                Resultado = v1 * v2
            });
        }

        [HttpGet("dividir")]
        public IActionResult Dividir(double v1, double v2)
        {
            if (v2 == 0)
                return BadRequest("No se puede dividir entre cero.");

            return Ok(new
            {
                Valor1 = v1,
                Valor2 = v2,
                Operacion = "división",
                Resultado = v1 / v2
            });
        }
    }
}
